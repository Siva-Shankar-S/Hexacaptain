const express = require("express");
const router = express.Router();
const userController = require("../controllers/users");

// Render Login Page
router.get(["/", "/login"], (req, res) => {
  res.render("login");
});

// Render Registration Page
router.get("/register", (req, res) => {
  res.render("register");
});

// Render Forgot Password Page
router.get("/forgot-password", (req, res) => {
  res.render("forgot-password");
});

// Render Reset Password Page
router.get("/reset-password/:token", (req, res) => {
  const { token } = req.params;
  res.render("reset-password", { token }); // Pass the token to the view
});

// Render Course Page (Protected)
router.get("/course", userController.isLoggedIn, (req, res) => {
  if (req.user) {
    res.render("course", { user: req.user });
  } else {
    res.redirect("/login");
  }
});

// Render Profile Page (Protected)
router.get("/profile", userController.isLoggedIn, (req, res) => {
  if (req.user) {
    res.render("profile", { user: req.user });
  } else {
    res.redirect("/login");
  }
});

// Render Home Page (Protected)
router.get("/home", userController.isLoggedIn, (req, res) => {
  if (req.user) {
    res.render("home", { user: req.user });
  } else {
    res.redirect("/login");
  }
});

module.exports = router;
