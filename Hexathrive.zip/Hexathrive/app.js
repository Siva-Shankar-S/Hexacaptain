const express = require("express");
const mysql = require("mysql2");
const dotenv = require("dotenv"); // Fixed spelling from doenv to dotenv
const path = require("path");
const hbs = require("hbs");
const cookieParser = require("cookie-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const nodemailer = require("nodemailer");

const app = express();

dotenv.config({
  path: "./.env",
});
const db = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASS,
  database: process.env.DATABASE,
});

db.connect((err) => {
  if (err) {
    console.log(err);
  } else {
    console.log("MySQL Connection Success");
  }
});

app.use(cookieParser());
app.use(express.urlencoded({ extended: false }));
app.use(express.json()); // Add JSON parsing for requests

const location = path.join(__dirname, "./public");
app.use(express.static(location));
app.set("view engine", "hbs");

const partialsPath = path.join(__dirname, "./views/partials");
hbs.registerPartials(partialsPath);

// Route for sending password reset email
app.post("/forgot-password", async (req, res) => {
  const { email } = req.body;

  // Check if the email exists in the database
  const userQuery = `SELECT * FROM users WHERE email = ?`;
  const [user] = await db.promise().query(userQuery, [email]);

  if (user.length === 0) {
    return res.status(404).send('Email not found');
  }

  // Generate a token valid for 10 minutes
  const token = jwt.sign({ email }, process.env.JWT_SECRET, { expiresIn: '10m' });

  // Send the reset email
  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: 'Password Reset',
    text: `Click the link to reset your password: http://localhost:5000/reset-password?token=${token}`,
  };

  transporter.sendMail(mailOptions, (error) => {
    if (error) {
      return res.status(500).send('Error sending email');
    }
    res.send('Password reset link sent to your email.');
  });
});

// Route for resetting password
app.post("/reset-password", async (req, res) => {
  const { token, newPassword } = req.body;

  // Verify the token
  jwt.verify(token, process.env.JWT_SECRET, async (err, decoded) => {
    if (err) {
      return res.status(400).send('Invalid or expired token');
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    const query = `UPDATE users SET password = ? WHERE email = ?`;
    await db.promise().query(query, [hashedPassword, decoded.email]);

    res.send('Password has been updated successfully.');
  });
});

app.use("/", require("./routes/pages"));
app.use("/auth", require("./routes/auth"));

app.listen(5000, () => {
  console.log("Server Started @ Port 5000");
});
